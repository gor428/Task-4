using System;
using System.Collections.Generic;

class Program
{
    const int BoardSize = 8;
    static bool[,] board = new bool[BoardSize, BoardSize];
    static bool[,] attackedFields = new bool[BoardSize, BoardSize];
    static List<(int row, int col)> kentavrs = new List<(int, int)>();

    static void Main(string[] args)
    {
        Console.WriteLine("Kentavr Placement on Chessboard");
        Console.WriteLine("Kentavr moves like both a Rook and a Knight");

        (int startRow, int startCol) = GetStartingPosition();
        PlaceKentavr(startRow, startCol);

        while (TryPlaceNextKentavr())
        {
            DisplayBoard();
            Console.WriteLine($"Placed {kentavrs.Count} kentavrs so far");
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        Console.WriteLine("\nFinal Placement:");
        DisplayBoard();
        Console.WriteLine($"Total kentavrs placed: {kentavrs.Count}");
        DisplayAttackCoverage();
    }

    static (int, int) GetStartingPosition()
    {
        while (true)
        {
            Console.Write("Enter starting position (e.g., 'a1'): ");
            string input = Console.ReadLine().ToLower();

            if (input.Length == 2 && 
                input[0] >= 'a' && input[0] <= 'h' &&
                input[1] >= '1' && input[1] <= '8')
            {
                int col = input[0] - 'a';
                int row = input[1] - '1';
                return (row, col);
            }
            Console.WriteLine("Invalid input. Please use format like 'a1' to 'h8'");
        }
    }

    static bool TryPlaceNextKentavr()
    {
        int maxFree = -1;
        (int row, int col) bestPos = (-1, -1);

        for (int r = 0; r < BoardSize; r++)
        {
            for (int c = 0; c < BoardSize; c++)
            {
                if (!board[r, c] && !attackedFields[r, c])
                {
                    int freeCount = CountFreeFieldsIfPlacedHere(r, c);
                    if (freeCount > maxFree)
                    {
                        maxFree = freeCount;
                        bestPos = (r, c);
                    }
                }
            }
        }

        if (maxFree == -1) return false;

        PlaceKentavr(bestPos.row, bestPos.col);
        return true;
    }

    static int CountFreeFieldsIfPlacedHere(int row, int col)
    {
        MarkAttackedFields(row, col, true, out _);
        
        int freeCount = 0;
        for (int r = 0; r < BoardSize; r++)
        {
            for (int c = 0; c < BoardSize; c++)
            {
                if (!board[r, c] && !attackedFields[r, c])
                {
                    freeCount++;
                }
            }
        }

        MarkAttackedFields(row, col, false, out _);
        return freeCount;
    }

    static void PlaceKentavr(int row, int col)
    {
        board[row, col] = true;
        kentavrs.Add((row, col));
        MarkAttackedFields(row, col, true, out _);
    }

    static void MarkAttackedFields(int row, int col, bool mark, out int newlyCovered)
    {
        newlyCovered = 0;

        for (int r = 0; r < BoardSize; r++)
        {
            if (r != row && !attackedFields[r, col] && mark) newlyCovered++;
            attackedFields[r, col] = mark;
        }
        for (int c = 0; c < BoardSize; c++)
        {
            if (c != col && !attackedFields[row, c] && mark) newlyCovered++;
            attackedFields[row, c] = mark;
        }

        int[] knightRows = { -2, -2, -1, -1, 1, 1, 2, 2 };
        int[] knightCols = { -1, 1, -2, 2, -2, 2, -1, 1 };

        for (int i = 0; i < 8; i++)
        {
            int r = row + knightRows[i];
            int c = col + knightCols[i];
            if (r >= 0 && r < BoardSize && c >= 0 && c < BoardSize)
            {
                if (!attackedFields[r, c] && mark) newlyCovered++;
                attackedFields[r, c] = mark;
            }
        }
    }

    static void DisplayBoard()
    {
        Console.WriteLine("\n  a b c d e f g h");
        for (int r = 0; r < BoardSize; r++)
        {
            Console.Write($"{r + 1} ");
            for (int c = 0; c < BoardSize; c++)
            {
                if (board[r, c])
                    Console.Write("K ");
                else if (attackedFields[r, c])
                    Console.Write(". ");
                else
                    Console.Write("_ ");
            }
            Console.WriteLine();
        }
    }

    static void DisplayAttackCoverage()
    {
        int covered = 0;
        for (int r = 0; r < BoardSize; r++)
            for (int c = 0; c < BoardSize; c++)
                if (attackedFields[r, c]) covered++;

        Console.WriteLine($"Attack coverage: {covered}/64 fields");
        Console.WriteLine($"Free fields remaining: {64 - covered - kentavrs.Count}");
    }
}
